# R Reproduction Notes

## Status

The pre-specified statistical analysis environment for this review (PROSPERO CRD4220261420579,
Protocol Field 17) is **R (≥4.4.0)** with packages `meta` (v7.0+) and `metafor` (v4.6+).
`scripts/phase5_analysis.py` in this repository is a **Python cross-validation
reimplementation** of the same methodology, produced during manuscript drafting when a local
R/CRAN environment was not available. This document tracks the status of confirming numerical
equivalence between the two implementations.

## Methodology being reproduced

- Random-effects meta-analysis of proportions
- Logit transformation of study-level proportions prior to pooling
- DerSimonian–Laird (DL) estimator for between-study variance (τ²)
- 0.5 continuity correction applied to any study with 0% or 100% observed proportion
- Back-transformation of the pooled logit estimate to the proportion scale for reporting
- Exact (Clopper–Pearson) binomial 95% CI substituted where k=1 (not a DL-estimable stratum)

## Suggested R script (for reviewers wishing to reproduce independently)

The following `meta`-package R code reproduces the DerSimonian–Laird logit-transform proportion
analysis for the k=2 "all-age" strata, reading directly from
`data/raw/Table_S2_extracted_data.csv`:

```r
library(meta)
library(dplyr)

dat <- read.csv("data/raw/Table_S2_extracted_data.csv")

# Example: TDT all-age stratum (uid6 + uid154_TDT)
tdt_all <- dat %>% filter(indication == "TDT", grepl("quantitative", role_in_synthesis))

m_tdt <- metaprop(
  event = n_events_numerator,
  n     = n_evaluable_denominator,
  studlab = study_id,
  data  = tdt_all,
  sm    = "PLOGIT",     # logit transform
  method.tau = "DL",    # DerSimonian-Laird
  method.ci  = "CP"     # Clopper-Pearson for individual-study CIs where applicable
)
summary(m_tdt)
forest(m_tdt)

# Repeat for indication == "SCD", and for the age_band == "5-11y" subsets (k=1; metaprop will
# still run but should be interpreted as a single-study exact CI per Methods 2.8 — cross-check
# against stats::binom.test() or exact2x2::binom.exact() for the k=1 strata specifically, since
# a DL model is not meaningfully estimable at k=1).
```

## Cross-validation status

| Stratum | Python output (this repo) | R output | Match confirmed? |
|---|---|---|---|
| TDT Angle A (k=1) | 100.0% (63.1–100.0%) | *pending* | ☐ |
| SCD Angle A (k=1) | 100.0% (63.1–100.0%) | *pending* | ☐ |
| TDT all-age (k=2) | 92.0% (79.3–97.1%) | *pending* | ☐ |
| SCD all-age (k=2) | 97.6% (84.5–99.7%) | *pending* | ☐ |

**Action for authors before submission:** run the R snippet above (or the full pre-specified
protocol pipeline) in a local R ≥4.4.0 environment with `meta` v7.0+ installed, populate the
"R output" column, and confirm matches. Given the closed-form nature of the DerSimonian–Laird
logit-transform calculation, exact numerical agreement (to rounding) is expected.

## Known non-equivalence: prediction intervals

The registered protocol (Field 17) specifies that 95% prediction intervals be reported alongside
— and emphasized over — I² alone. `scripts/phase5_analysis.py` does **not** currently compute
prediction intervals, as they were judged not meaningfully estimable at k=1 or k=2 (a prediction
interval requires a t-distribution with k-2 degrees of freedom, which is undefined for k≤2).
`meta::metaprop()` in R will likewise return `NA` or a degenerate result for prediction intervals
at k=2; authors should confirm this behaviour matches and document it explicitly in the
manuscript rather than treating it as a discrepancy to resolve.
