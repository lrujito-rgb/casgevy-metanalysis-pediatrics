# PROSPERO Protocol Summary

**Registration number:** CRD4220261420579
**Protocol version:** v1.0, June 2026
**Title:** Efficacy and Safety of Exagamglogene Autotemcel (Casgevy) in Paediatric Patients with
Sickle Cell Disease and Transfusion-Dependent Beta-Thalassemia: A Systematic Review and
Meta-Analysis

## Review team

| Role | Name | ORCID | Affiliation |
|---|---|---|---|
| Guarantor & Named Contact | Lantip Rujito | [0000-0001-6595-3265](https://orcid.org/0000-0001-6595-3265) | Faculty of Medicine, Universitas Jenderal Soedirman, Indonesia |
| Co-investigator | Wahyu Siswandari | [0000-0003-1836-8367](https://orcid.org/0000-0003-1836-8367) | Faculty of Medicine, Universitas Jenderal Soedirman, Indonesia |
| Co-investigator | Vitasari Indriani | [0000-0001-8563-1781](https://orcid.org/0000-0001-8563-1781) | Faculty of Medicine, Universitas Jenderal Soedirman, Indonesia |

## Key protocol parameters (abbreviated — see full protocol document for complete text)

- **Population:** Paediatric patients 5–17 years with severe SCD (recurrent VOCs) or TDT (any
  genotype); **Angle A = 5–11 years, the primary/first staged output** (this repository); Angle B
  (12–17 years) is a planned separate future output.
- **Intervention:** Exagamglogene autotemcel (exa-cel; Casgevy), single IV infusion following
  busulfan myeloablative conditioning.
- **Comparator:** None required (single-arm proportional synthesis); CLIMB standard-of-care
  observational cohort (Mahesri et al., 2024) referenced narratively/non-inferentially only.
- **Databases:** PubMed/MEDLINE, Embase.com, Cochrane CENTRAL, Scopus, Web of Science Core
  Collection, plus grey literature (ClinicalTrials.gov, WHO ICTRP, FDA approval documents, EMA
  EPARs, ASH/EHA/EBMT 2019–2025 proceedings). No language or date restriction.
- **Search/screening conducted:** June–August 2026.
- **Risk of bias tool:** JBI Critical Appraisal Checklist for Case Series (10-item); NOS specified
  as a contingency for comparative observational designs (not applicable — none identified).
- **Statistical model:** Random-effects, logit-transformed proportions, DerSimonian-Laird
  estimator; **minimum k=3 studies required for formal pooling** (see the protocol-compliance
  note in the main README — this threshold was not met in either analysed stratum, and is
  explicitly disclosed).
- **Software (pre-specified):** R ≥4.4.0, `meta` v7.0+, `metafor` v4.6+, `ggplot2` v3.5+.
- **Reporting bias assessment:** Funnel plot + Egger's test only if ≥10 studies; narrative
  discussion otherwise (applicable here, k<10 throughout).
- **Certainty of evidence:** Narrative GRADE-like assessment; ceiling explicitly acknowledged as
  "very low to low" given the single-arm, uncontrolled design of all included evidence.
- **Funding:** None declared.
- **AI-tool use:** Disclosed per protocol Field 24 (see manuscript Author/Funding block).

For the complete, verbatim protocol (all 24 PROSPERO fields), refer to the original protocol
document (`PROSPERO_Casgevy_Protocol_v1.docx`, held by the review team; not redistributed in this
public repository pending the authors' own decision on whether to deposit it alongside the
PROSPERO registration record itself, which is the canonical public reference).
