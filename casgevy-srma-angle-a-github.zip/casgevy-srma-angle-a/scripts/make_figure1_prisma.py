from pathlib import Path
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyArrowPatch

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 9.5,
})

fig, ax = plt.subplots(figsize=(11, 13))
ax.set_xlim(0, 100)
ax.set_ylim(0, 130)
ax.axis("off")

BOX_W = 40
def box(x, y, w, h, text, fc="white", ec="black", fontsize=9.2, weight="normal"):
    rect = mpatches.FancyBboxPatch((x, y), w, h, boxstyle="square,pad=0.3",
                                    linewidth=1.1, edgecolor=ec, facecolor=fc)
    ax.add_patch(rect)
    ax.text(x + w/2, y + h/2, text, ha="center", va="center",
             fontsize=fontsize, weight=weight, wrap=True, linespacing=1.35)
    return (x + w/2, y, x + w/2, y + h)

def arrow(x1, y1, x2, y2):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>",
                                  mutation_scale=14, linewidth=1.1, color="black"))

def side_label(x, y, text, fontsize=8.3):
    ax.text(x, y, text, ha="left", va="center", fontsize=fontsize, style="italic")

# Column layout
LX = 5    # left column x (main flow)
LW = 42
RX = 52   # right column x (excluded boxes)
RW = 44

# ── Identification ──────────────────────────────────────────
y = 122
ax.text(LX, y + 4, "Identification", fontsize=11, weight="bold")
b1_c, b1_by, b1_cx, b1_ty = box(LX, y - 6, LW, 9,
    "Records identified from databases\n(n = 1,831)\n5 databases + grey literature",
    fc="#EAF2FB")

y2 = y - 6
arrow(LX + LW/2, y2, LX + LW/2, y2 - 7)

# ── Screening ────────────────────────────────────────────────
y3 = y2 - 16
ax.text(LX, y3 + 9, "Screening", fontsize=11, weight="bold")
box(LX, y3, LW, 9, "Records after duplicates removed\n(n = 1,073)", fc="#EAF2FB")

arrow(LX + LW/2, y3, LX + LW/2, y3 - 7)

y4 = y3 - 16
box(LX, y4, LW, 9, "Records screened\n(title/abstract)\n(n = 1,073)", fc="#EAF2FB")
# excluded box to the right
box(RX, y4 - 1.5, RW, 12,
    "Records excluded (n = 1,007)\n"
    "\u2022 Both reviewers agreed: n = 120\n"
    "\u2022 R3 adjudication: n = 22\n"
    "\u2022 Conservative auto-exclude (valid E1\u2013E4 codes): n = 851\n"
    "\u2022 Ineligible product (BRL-101/RM-001): n = 14",
    fc="#FDEDEC", fontsize=8.0)
arrow(LX + LW, y4 + 4.5, RX, y4 + 4.5)

arrow(LX + LW/2, y4, LX + LW/2, y4 - 7)

y5 = y4 - 16
box(LX, y5, LW, 9, "Reports sought for retrieval\n(n = 66)", fc="#EAF2FB")
arrow(LX + LW/2, y5, LX + LW/2, y5 - 7)

# ── Eligibility ──────────────────────────────────────────────
y6 = y5 - 20
ax.text(LX, y6 + 13, "Eligibility", fontsize=11, weight="bold")
box(LX, y6, LW, 13, "Reports assessed for eligibility\n(full text)\n(n = 66)",
    fc="#EAF2FB")
box(RX, y6 - 4, RW, 29,
    "Reports excluded (n = 55)\n"
    "\u2022 Superseded / duplicate report of the same\n"
    "   patient cohort (earlier data cutoff, incl. 1\n"
    "   duplicate-UID entry of an already-counted\n"
    "   record, uid1067\u2261uid417): n = 38\n"
    "\u2022 Trial-registry entry (ClinicalTrials.gov),\n"
    "   no extractable outcome data: n = 11\n"
    "\u2022 Ineligible investigational product\n"
    "   (BRL-101/RM-001, distinct from exa-cel): n = 1\n"
    "\u2022 Non-poolable / out-of-scope secondary\n"
    "   content (single-patient case report,\n"
    "   n=2 mechanistic study, apheresis/\n"
    "   manufacturing report): n = 3\n"
    "\u2022 Regulatory approval correspondence, not a\n"
    "   primary/secondary data report (FDA BLA\n"
    "   approval letters): n = 2",
    fc="#FDEDEC", fontsize=7.5)
arrow(LX + LW, y6 + 6.5, RX, y6 + 6.5)

arrow(LX + LW/2, y6, LX + LW/2, y6 - 7)

# ── Included ─────────────────────────────────────────────────
y7 = y6 - 20
ax.text(LX, y7 + 14, "Included", fontsize=11, weight="bold")
box(LX, y7, LW, 14,
    "Studies included in qualitative synthesis\n(n = 11 unique reports)\n\n"
    "Primary efficacy (pooled): TDT n=2, SCD n=2\n"
    "Secondary/narrative (sensitivity, safety, QoL,\n"
    "mechanism, methodology): n = 7",
    fc="#EAF9F0")

arrow(LX + LW/2, y7, LX + LW/2, y7 - 7)

y8 = y7 - 15
box(LX, y8, LW, 12,
    "Studies included in quantitative synthesis\n"
    "(meta-analysis of proportions)\n(n = 4 data rows from 2 primary reports)\n\n"
    "TDT: uid6 (12\u201335y) + uid154 (5\u201311y, Angle A)\n"
    "SCD: uid416 (12\u201335y) + uid154 (5\u201311y, Angle A)",
    fc="#EAF9F0")

fig.suptitle("Figure 1. PRISMA 2020 flow diagram\n"
             "Exagamglogene autotemcel (exa-cel) in paediatric SCD and TDT: systematic review and meta-analysis",
             fontsize=11.5, weight="bold", y=0.995)

plt.tight_layout(rect=[0, 0, 1, 0.97])
plt.savefig(str(Path(__file__).resolve().parents[1] / "figures" / "Figure1_PRISMA_flow.png"), dpi=300, bbox_inches="tight", facecolor="white")
print("saved PRISMA")
