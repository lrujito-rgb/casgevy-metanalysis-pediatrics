#!/usr/bin/env python3
"""
phase5_analysis.py
===================
Casgevy (exagamglogene autotemcel) SR-MA — Angle A (paediatric 5-11y) + all-age context
PROSPERO CRD4220261420579

Reproducible proportion meta-analysis (DerSimonian-Laird, logit-transform, with 0.5 continuity
correction for 0%/100% cells; exact Clopper-Pearson CI for k=1 strata).

NOTE ON PROTOCOL COMPLIANCE
----------------------------
The registered protocol (Field 17) specifies a minimum of k=3 independent studies before formal
meta-analytic pooling; neither stratum analysed here meets that threshold (Angle A: k=1;
all-age context: k=2). Outputs are therefore explicitly labelled as "single-study exact CI" or
"exploratory DerSimonian-Laird estimate" rather than a fully-powered random-effects
meta-analysis. See manuscript Methods 2.8 for full disclosure and rationale.

NOTE ON SOFTWARE
----------------
The pre-specified protocol analysis environment is R (>=4.4.0) with packages `meta` (v7.0+) and
`metafor` (v4.6+). This script is a Python (numpy/scipy/pandas) reimplementation used during
drafting for cross-validation when a local R/CRAN environment was unavailable. Authors intend
to confirm numerical equivalence against the pre-specified R pipeline before submission
(see docs/R_reproduction_notes.md).

Usage
-----
    python scripts/phase5_analysis.py
    # reads data/raw/Table_S2_extracted_data.csv
    # writes results/Phase5_pooled_results.csv
"""
import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INPUT = REPO_ROOT / "data" / "raw" / "Table_S2_extracted_data.csv"
DEFAULT_OUTPUT = REPO_ROOT / "results" / "Phase5_pooled_results.csv"


def load_extracted_data(path: Path) -> pd.DataFrame:
    """Load the study-level event/denominator data extracted during Phase 4."""
    df = pd.read_csv(path)
    required = {"study_id", "indication", "age_band", "n_evaluable_denominator",
                "n_events_numerator", "role_in_synthesis"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Input CSV is missing required columns: {missing}")
    return df


def back_calc_check(df: pd.DataFrame, label: str) -> pd.DataFrame:
    """DI-2 style sanity check: proportions must lie in [0, 1], n must be > 0."""
    df = df.copy()
    df["prop_calc"] = df["n_events_numerator"] / df["n_evaluable_denominator"]
    bad = df[(df["prop_calc"] < 0) | (df["prop_calc"] > 1)]
    if len(bad):
        print(f"  FLAG {label}: proportion out of [0,1] in {len(bad)} rows")
    else:
        print(f"  {label}: all proportions within [0,1] — PASS")
    zeros = df[df["n_evaluable_denominator"] == 0]
    if len(zeros):
        print(f"  FLAG {label}: n=0 in {len(zeros)} rows")
    return df


def logit_re_pool(df: pd.DataFrame, cc: float = 0.5) -> dict:
    """
    Random-effects meta-analysis of proportions, logit transform, DerSimonian-Laird tau^2.
    Continuity correction `cc` applied only to studies with events=0 or events=n.
    For k=1, returns the exact Clopper-Pearson 95% CI instead (no RE model is estimable).
    """
    df = df.copy()
    x = df["n_events_numerator"].astype(float).values
    n = df["n_evaluable_denominator"].astype(float).values
    needs_cc = (x == 0) | (x == n)
    x_cc = np.where(needs_cc, x + cc, x)
    n_cc = np.where(needs_cc, n + 2 * cc, n)

    p = x_cc / n_cc
    yi = np.log(p / (1 - p))                       # logit
    vi = 1 / x_cc + 1 / (n_cc - x_cc)               # var(logit p)

    k = len(df)
    if k == 1:
        x0, n0 = x[0], n[0]
        if x0 < n0:
            lo, hi = stats.beta.interval(0.95, x0, n0 - x0 + 1)
        else:
            lo = stats.beta.ppf(0.025, x0, n0 - x0 + 1)
            hi = 1.0
        pooled_p = x0 / n0
        return dict(k=k, pooled_p=pooled_p, ci_lo=lo, ci_hi=hi,
                    tau2=np.nan, i2=np.nan, method="single-study exact (Clopper-Pearson)",
                    table=df)

    wi = 1 / vi
    yi_bar_fe = np.sum(wi * yi) / np.sum(wi)
    Q = np.sum(wi * (yi - yi_bar_fe) ** 2)
    df_Q = k - 1
    C = np.sum(wi) - np.sum(wi ** 2) / np.sum(wi)
    tau2 = max(0, (Q - df_Q) / C) if C > 0 else 0.0
    i2 = max(0, (Q - df_Q) / Q) * 100 if Q > 0 else 0.0

    wi_re = 1 / (vi + tau2)
    yi_bar_re = np.sum(wi_re * yi) / np.sum(wi_re)
    se_re = np.sqrt(1 / np.sum(wi_re))
    z = 1.959963985
    lo_logit, hi_logit = yi_bar_re - z * se_re, yi_bar_re + z * se_re

    inv_logit = lambda v: 1 / (1 + np.exp(-v))
    pooled_p = inv_logit(yi_bar_re)
    ci_lo, ci_hi = inv_logit(lo_logit), inv_logit(hi_logit)

    df["prop_raw"] = x / n
    df["weight_pct"] = 100 * wi_re / np.sum(wi_re)
    return dict(k=k, pooled_p=pooled_p, ci_lo=ci_lo, ci_hi=ci_hi,
                tau2=tau2, i2=i2, Q=Q, df_Q=df_Q,
                method="DerSimonian-Laird random-effects, logit transform (EXPLORATORY, k<3)",
                table=df)


def report(res: dict, label: str) -> None:
    print(f"\n--- {label} (k={res['k']}, method: {res['method']}) ---")
    print(f"Estimate: {res['pooled_p']*100:.1f}% "
          f"(95% CI: {res['ci_lo']*100:.1f}%-{res['ci_hi']*100:.1f}%)")
    if not np.isnan(res.get("tau2", np.nan)):
        print(f"tau^2 = {res['tau2']:.4f}, I^2 = {res['i2']:.1f}%, "
              f"Q({res['df_Q']}) = {res['Q']:.3f}")
    print(res["table"][["study_id", "n_evaluable_denominator", "n_events_numerator"]]
          .to_string(index=False))


def main(input_path: Path = DEFAULT_INPUT, output_path: Path = DEFAULT_OUTPUT) -> pd.DataFrame:
    data = load_extracted_data(input_path)

    dat_tdt = data[(data.indication == "TDT") &
                   (data.role_in_synthesis.str.contains("quantitative", case=False))]
    dat_scd = data[(data.indication == "SCD") &
                   (data.role_in_synthesis.str.contains("quantitative", case=False))]

    print("=" * 70)
    print("DI-7: k derived from data, never hand-typed")
    print(f"k TDT (all quantitative rows): {len(dat_tdt)}")
    print(f"k SCD (all quantitative rows): {len(dat_scd)}")
    print("=" * 70)

    print("\n=== Sanity checks ===")
    dat_tdt = back_calc_check(dat_tdt, "TDT")
    dat_scd = back_calc_check(dat_scd, "SCD")

    print("\n" + "=" * 70)
    print("PRIMARY ANALYSIS — ANGLE A (Pediatric 5-11 yr)")
    print("=" * 70)
    res_tdt_ped = logit_re_pool(dat_tdt[dat_tdt.age_band == "5-11y"])
    res_scd_ped = logit_re_pool(dat_scd[dat_scd.age_band == "5-11y"])
    report(res_tdt_ped, "TDT Angle A (TI12)")
    report(res_scd_ped, "SCD Angle A (VF12)")

    print("\n" + "=" * 70)
    print("CONTEXTUAL ANALYSIS — All ages (Angle A + adult/adolescent pivotal)")
    print("=" * 70)
    res_tdt_all = logit_re_pool(dat_tdt)
    res_scd_all = logit_re_pool(dat_scd)
    report(res_tdt_all, "TDT all-age (TI12)")
    report(res_scd_all, "SCD all-age (VF12)")

    summary_rows = []
    for label, res in [("TDT_AngleA_5-11", res_tdt_ped), ("SCD_AngleA_5-11", res_scd_ped),
                        ("TDT_AllAge_pooled", res_tdt_all), ("SCD_AllAge_pooled", res_scd_all)]:
        summary_rows.append(dict(
            analysis=label, k=res["k"],
            pooled_pct=round(res["pooled_p"] * 100, 1),
            ci_lo_pct=round(res["ci_lo"] * 100, 1),
            ci_hi_pct=round(res["ci_hi"] * 100, 1),
            tau2=res.get("tau2", np.nan), i2_pct=res.get("i2", np.nan),
            method=res["method"],
        ))
    summary_df = pd.DataFrame(summary_rows)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    summary_df.to_csv(output_path, index=False)
    print(f"\nSaved: {output_path}")
    print(summary_df.to_string(index=False))
    return summary_df


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT,
                         help="Path to extracted study-level CSV")
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT,
                         help="Path to write pooled-results CSV")
    args = parser.parse_args()
    main(args.input, args.output)
