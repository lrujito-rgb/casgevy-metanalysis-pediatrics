from pathlib import Path
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

df = pd.read_csv(str(Path(__file__).resolve().parents[1] / "results" / "Phase5_pooled_results.csv"))

# Order rows top-to-bottom as they should appear (reverse for plotting bottom-up)
order = ["TDT_AngleA_5-11", "TDT_AllAge_pooled", "SCD_AngleA_5-11", "SCD_AllAge_pooled"]
df = df.set_index("analysis").loc[order].reset_index()

labels = [
    "TDT \u2014 Angle A (5\u201311 y)\nuid154 only, k=1, exact CI",
    "TDT \u2014 All-age pooled\nuid6 + uid154, k=2, DL logit",
    "SCD \u2014 Angle A (5\u201311 y)\nuid154 only, k=1, exact CI",
    "SCD \u2014 All-age pooled\nuid416 + uid154, k=2, DL logit",
]

y_pos = np.arange(len(df))[::-1]  # top row = first entry

fig, ax = plt.subplots(figsize=(8.5, 4.8))

colors = ["#2E75B6", "#2E75B6", "#C0392B", "#C0392B"]

for i, (yp, row, color) in enumerate(zip(y_pos, df.itertuples(), colors)):
    lo, hi, pt = row.ci_lo_pct, row.ci_hi_pct, row.pooled_pct
    ax.plot([lo, hi], [yp, yp], color=color, linewidth=1.8, zorder=2)
    ax.plot(pt, yp, "s", color=color, markersize=9, zorder=3)
    ax.text(hi + 2.0, yp, f"{pt:.1f}% ({lo:.1f}\u2013{hi:.1f}%)", va="center",
            fontsize=9.3, color="black")

ax.axvline(100, color="grey", linestyle=":", linewidth=0.8, zorder=1)
ax.set_yticks(y_pos)
ax.set_yticklabels(labels, fontsize=9.3)
ax.set_xlim(50, 118)
ax.set_xlabel("Pooled proportion achieving primary endpoint\n"
              "(TI12 for TDT; VF12 for SCD), % (95% CI)", fontsize=9.5)
ax.set_title("Figure 2. Pooled proportions achieving the primary efficacy endpoint,\n"
             "by indication and age stratum", fontsize=11, weight="bold")
ax.spines[["top", "right"]].set_visible(False)
ax.tick_params(axis="x", labelsize=9)

# Reference note
fig.text(0.02, -0.02,
    "Angle A (k=1) rows show exact (Clopper-Pearson) 95% CI for a single non-overlapping study;\n"
    "All-age pooled rows (k=2) show DerSimonian-Laird random-effects logit-transform estimates.\n"
    "TI12: transfusion independence \u226512 months. VF12: freedom from severe VOC \u226512 months.",
    fontsize=7.6, style="italic", ha="left")

plt.tight_layout()
plt.savefig(str(Path(__file__).resolve().parents[1] / "figures" / "Figure2_forest_pooled_proportions.png"),
            dpi=300, bbox_inches="tight", facecolor="white")
print("saved forest plot")
