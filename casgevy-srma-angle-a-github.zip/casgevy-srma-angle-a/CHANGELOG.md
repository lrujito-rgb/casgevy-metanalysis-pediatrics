# Changelog

## [1.0.0] — 2026-07-19
### Added
- Initial public release of extraction data (`data/raw/`) and analysis code (`scripts/`) for the
  Casgevy SR-MA Angle A (paediatric 5–11 years) manuscript.
- `phase5_analysis.py`: reproducible DerSimonian-Laird / exact-CI proportion meta-analysis,
  reading from `data/raw/Table_S2_extracted_data.csv`.
- `make_figure1_prisma.py`, `make_figure2_forest.py`: figure-generation scripts.
- Full PRISMA disposition of all 66 full-text-screened records
  (`data/raw/Table_S1_full_text_disposition.csv`).
- GitHub Actions workflow (`.github/workflows/reproduce.yml`) to verify end-to-end
  reproducibility on every push.
- Explicit protocol-compliance disclosure: registered protocol (PROSPERO CRD4220261420579)
  specifies a minimum k=3 studies for formal pooling; neither analysed stratum (k=1 Angle A;
  k=2 all-age context) meets this threshold — see README "Protocol-compliance note" and
  `docs/R_reproduction_notes.md`.

### Known outstanding items (tracked for v1.1.0)
- R-pipeline cross-validation not yet numerically confirmed (see
  `docs/R_reproduction_notes.md` cross-validation table).
- 95% prediction intervals and REML-alternative-estimator sensitivity analysis (both
  protocol-specified) not yet computed.
- JBI Critical Appraisal Checklist item-level scores not yet finalized (total scores only).
