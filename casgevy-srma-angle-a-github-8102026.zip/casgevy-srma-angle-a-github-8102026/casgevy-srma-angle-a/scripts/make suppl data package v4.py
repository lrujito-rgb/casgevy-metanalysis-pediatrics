#!/usr/bin/env python3
"""
Supplementary Data Package — Casgevy SR-MA (Angle A)
v4, 27 September 2026.

Rebuilt after the search window was set to 4 August 2026, which brings the
FDA supplemental approval of 1 July 2026 into scope as an identified,
full-text-excluded regulatory document.
"""
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

F = "Arial"
HDR_FILL = PatternFill("solid", fgColor="D9D9D9")
NEW_FILL = PatternFill("solid", fgColor="FFF2CC")   # changed since v3
TODO_FILL = PatternFill("solid", fgColor="FCE4E4")  # author must complete
THIN = Side(style="thin", color="999999")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

wb = openpyxl.Workbook()


def sheet(name, headers, rows, widths, title=None, notes=None, wrap_cols=()):
    ws = wb.create_sheet(name)
    r = 1
    if title:
        ws.cell(r, 1, title).font = Font(name=F, bold=True, size=13)
        r += 2
    hr = r
    for j, h in enumerate(headers, 1):
        c = ws.cell(hr, j, h)
        c.font = Font(name=F, bold=True, size=10)
        c.fill = HDR_FILL
        c.border = BORDER
        c.alignment = Alignment(wrap_text=True, vertical="center")
    r = hr + 1
    for row in rows:
        flag = None
        if isinstance(row, tuple) and len(row) == 2 and isinstance(row[0], list):
            row, flag = row[0], row[1]
        for j, v in enumerate(row, 1):
            c = ws.cell(r, j, v)
            c.font = Font(name=F, size=10)
            c.border = BORDER
            c.alignment = Alignment(
                wrap_text=(j in wrap_cols), vertical="top")
            if flag == "NEW":
                c.fill = NEW_FILL
            elif flag == "TODO":
                c.fill = TODO_FILL
        r += 1
    if notes:
        r += 1
        for n in notes:
            c = ws.cell(r, 1, n)
            c.font = Font(name=F, size=9, italic=True)
            r += 1
    for j, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(j)].width = w
    ws.freeze_panes = ws.cell(hr + 1, 1)
    return ws


# ------------------------------------------------------------------ README
ws = wb.active
ws.title = "README"
readme = [
    ("Supplementary Data Package", 14, True),
    ("Efficacy and Safety of Exagamglogene Autotemcel (Casgevy) in Paediatric "
     "Patients with Sickle Cell Disease and Transfusion-Dependent "
     "Beta-Thalassemia: A Systematic Review and Meta-Analysis "
     "(Angle A: Ages 5-11 Years)", 10, False),
    ("", 10, False),
    ("Version", 11, True),
    ("v4 — 27 September 2026", 10, False),
    ("", 10, False),
    ("PROSPERO", 11, True),
    ("CRD420261420579 (registered 10 June 2026, Protocol v1.0)", 10, False),
    ("", 10, False),
    ("Code and data repository", 11, True),
    ("https://github.com/lrujito-rgb/casgevy-metanalysis-pediatrics", 10, False),
    ("", 10, False),
    ("What changed in v4", 11, True),
    ("The search window was set to a single date, 4 August 2026, across all "
     "sources. That window encloses the FDA supplemental paediatric approval "
     "of 1 July 2026 and its revised prescribing information, which is "
     "therefore an identified record, excluded at full text as a regulatory "
     "document and consulted for endpoint and denominator definitions only.",
     10, False),
    ("", 10, False),
    ("Consequences, all reflected in this workbook:", 10, False),
    ("   Records identified            1831  ->  1832", 10, False),
    ("   Records screened after dedup  1073  ->  1074", 10, False),
    ("   Reports assessed at full text   66  ->    67", 10, False),
    ("   Reports excluded at full text   55  ->    56", 10, False),
    ("   Regulatory documents excluded    2  ->     3", 10, False),
    ("   Studies included                11  ->    11  (unchanged)", 10, False),
    ("", 10, False),
    ("Two further changes carried into v4:", 10, False),
    ("   Table S3 now reports the post hoc regulatory-denominator "
     "sensitivity analysis (manuscript Table 3).", 10, False),
    ("   The paediatric cohort is recorded as having been reported four "
     "times, not three; the fourth is the EHA June 2026 congress "
     "presentation.", 10, False),
    ("", 10, False),
    ("Sheet index", 11, True),
    ("   Table S1   Disposition of all 67 full-text records", 10, False),
    ("   Table S2   Extracted data, quantitative and narrative sources", 10, False),
    ("   Table S3   Pooled and sensitivity estimates", 10, False),
    ("   Table S4   JBI item-level quality appraisal", 10, False),
    ("   Data Dictionary", 10, False),
    ("", 10, False),
    ("Colour key", 11, True),
    ("   Amber cells  = value changed in v4", 10, False),
    ("   Pink cells   = author must complete before submission", 10, False),
    ("", 10, False),
    ("Licence", 11, True),
    ("Code MIT. Extracted data CC BY 4.0.", 10, False),
]
for i, (txt, sz, bold) in enumerate(readme, 1):
    c = ws.cell(i, 1, txt)
    c.font = Font(name=F, size=sz, bold=bold)
    c.alignment = Alignment(wrap_text=True, vertical="top")
ws.column_dimensions["A"].width = 110
ws.cell(2, 1).alignment = Alignment(wrap_text=True, vertical="top")
for rr in (2, 15, 17):
    ws.row_dimensions[rr].height = 48

# ------------------------------------------------------------ TABLE S1
s1_rows = [
    (["SUMMARY — identification and screening", "", "", "", ""], None),
    (["Records identified (all sources, to 4 August 2026)", "1832", "", "", ""], "NEW"),
    (["Duplicate records removed before screening", "758", "", "", ""], None),
    (["Records screened at title and abstract", "1074", "", "", ""], "NEW"),
    (["Records excluded at title and abstract", "1007", "", "", ""], None),
    (["   Concordant reviewer judgement", "120", "", "", ""], None),
    (["   Excluded after third-reviewer adjudication", "22", "", "", ""], None),
    (["   Conservative screening exclusion, valid E1-E4 code", "851", "", "", ""], None),
    (["   Ineligible investigational product", "14", "", "", ""], None),
    (["Reports sought for retrieval", "67", "", "", ""], "NEW"),
    (["Reports not retrieved", "0", "", "", ""], None),
    (["Reports assessed for eligibility at full text", "67", "", "", ""], "NEW"),
    (["Reports excluded at full text", "56", "", "", ""], "NEW"),
    (["   Superseded or duplicate report of an already-represented cohort", "38", "", "", ""], None),
    (["   Trial-register entry, no extractable outcome data", "11", "", "", ""], None),
    (["   Regulatory document, ineligible as an included study", "3", "", "", ""], "NEW"),
    (["   Non-poolable or out of scope", "3", "", "", ""], None),
    (["   Ineligible investigational product", "1", "", "", ""], None),
    (["Studies included in qualitative synthesis", "11", "", "", ""], None),
    (["Reports contributing to quantitative synthesis", "2 (4 data rows)", "", "", ""], None),
    (["", "", "", "", ""], None),
    (["RECORD-LEVEL DISPOSITION", "", "", "", ""], None),
    (["Frangoul et al. 2026a — Exa-cel in children with TDT or SCD",
      "NEJM, 11 Jun 2026", "NCT05356195; NCT05329649", "INCLUDED",
      "Paediatric primary source; both indications"], None),
    (["Locatelli et al. 2024 — Exa-cel for TDT",
      "NEJM 2024", "NCT03655678", "INCLUDED",
      "Adult/adolescent TDT pivotal; all-age context"], None),
    (["Grupp et al. 2025 — Long-term follow-up, exa-cel for SCD",
      "Conference poster 2025", "NCT03745287; NCT04208529", "INCLUDED",
      "Adult/adolescent SCD final analysis; all-age context"], None),
    (["Frangoul et al. 2024 — Exa-cel for severe SCD",
      "NEJM 2024", "NCT03745287", "INCLUDED (sensitivity only)",
      "Interim SCD estimate superseded by Grupp 2025"], None),
    (["Frangoul et al. 2026c — Busulfan PK and VOD incidence",
      "TCT 2026 abstract", "NCT03655678; NCT03745287", "INCLUDED (narrative)",
      "Safety context; VOD 12.5% TDT, 2.2% SCD"], None),
    (["Frangoul et al. 2025 — VOC endpoint definition methodology",
      "Adv Ther 2025", "n/a", "INCLUDED (narrative)",
      "Cross-therapy endpoint harmonisation"], None),
    (["[COMPLETE] Remaining five narrative sources", "", "", "INCLUDED (narrative)",
      "QoL x2, iron biomarkers x2, off-target editing x1"], "TODO"),
    (["ASH 2025 oral abstract — paediatric cohort, cutoff Apr 2025",
      "ASH 2025", "NCT05356195; NCT05329649", "EXCLUDED — superseded",
      "Overlap chain report 1 of 4"], None),
    (["Pediatric Blood & Cancer poster pair — cutoff Jul 2025",
      "PBC 2025", "NCT05356195; NCT05329649", "EXCLUDED — superseded",
      "Overlap chain report 2 of 4"], None),
    (["EHA 2026 congress presentation — paediatric cohort",
      "EHA, Jun 2026", "NCT05356195; NCT05329649", "EXCLUDED — superseded",
      "Overlap chain report 4 of 4; source of the 23.4-month mean "
      "duration figure, which was removed from the manuscript because "
      "its only provenance was this excluded report"], None),
    (["FDA BLA 125787 approval letter — SCD",
      "FDA, Dec 2023", "n/a", "EXCLUDED — regulatory document",
      "Cited in Introduction"], None),
    (["FDA BLA 125787 approval letter — TDT",
      "FDA, Jan 2024", "n/a", "EXCLUDED — regulatory document",
      "Cited in Introduction"], None),
    (["FDA supplemental approval and revised prescribing information, "
      "ages 2 years and older",
      "FDA, 1 Jul 2026", "n/a", "EXCLUDED — regulatory document",
      "NEW IN v4. Source of the regulatory efficacy denominator (8 of 9) "
      "and the 20.1-month median duration. Consulted for endpoint and "
      "denominator definitions only; not an included study"], "NEW"),
    (["[COMPLETE] Remaining 46 excluded records",
      "", "", "EXCLUDED",
      "Paste rows from the v3 workbook; category counts above already "
      "reconcile to 56"], "TODO"),
]
sheet("Table S1",
      ["Record / category", "Source and date", "Trial registry identifier",
       "Disposition", "Note"],
      s1_rows, [56, 22, 30, 30, 52],
      title="Table S1. Disposition of all 67 full-text records",
      notes=["Category counts reconcile exactly: 38 + 11 + 3 + 3 + 1 = 56 "
             "excluded; 67 - 56 = 11 included.",
             "Rows shaded pink must be completed from the v3 workbook before "
             "submission. No record-level data were regenerated for v4; only "
             "the category counts and the one new record were changed."],
      wrap_cols=(1, 5))

# ------------------------------------------------------------ TABLE S2
s2_rows = [
    ["Frangoul et al. 2026a", "CLIMB THAL-141", "NCT05356195", "TDT",
     "5-11 y", "15", "8", "TI12", "8", "100.0", "63.1-100.0",
     "16 Jan 2026 [VERIFY]", "Quantitative — Angle A"],
    ["Frangoul et al. 2026a", "CLIMB SCD-151", "NCT05329649", "SCD",
     "5-11 y", "11", "8", "VF12", "8", "100.0", "63.1-100.0",
     "16 Jan 2026 [VERIFY]", "Quantitative — Angle A"],
    ["Locatelli et al. 2024", "CLIMB THAL-111", "NCT03655678", "TDT",
     "12-35 y", "52", "35", "TI12", "32", "91.4", "76.9-98.2",
     "16 Jan 2023", "Quantitative — all-age context"],
    ["Grupp et al. 2025", "CLIMB SCD-121 + CLIMB-131", "NCT03745287",
     "SCD", "12-34 y", "46", "45", "VF12", "45", "100.0", "92.1-100.0",
     "10 Apr 2025", "Quantitative — all-age context"],
    ["US FDA 2026 (label)", "CLIMB THAL-141", "NCT05356195", "TDT",
     "5-11 y", "15", "9", "TI12", "8", "88.9", "51.8-99.7",
     "Label rev. Jul 2026", "Sensitivity — regulatory denominator"],
    ["Frangoul et al. 2024", "CLIMB SCD-121", "NCT03745287", "SCD",
     "12-35 y", "44", "30", "VF12", "29", "96.7", "82.8-99.9",
     "14 Jun 2023", "Sensitivity — data maturity"],
    ["Frangoul et al. 2026c", "CLIMB THAL-111 + CLIMB SCD-121", "Multiple",
     "TDT, SCD", "12-35 y", "56 + 46", "n/a", "VOD incidence", "7 / 1",
     "12.5 / 2.2", "n/a", "10 Apr 2025", "Narrative — safety"],
    ["Frangoul et al. 2025", "Cross-trial methodology", "n/a", "SCD",
     "12-35 y", "n/a", "n/a", "VOC definition", "n/a",
     "96.7 vs 100 on identical data", "n/a", "n/a",
     "Narrative — limitations"],
    (["[COMPLETE] Five remaining narrative sources", "", "", "", "", "",
      "", "", "", "", "", "", "Narrative"], "TODO"),
]
sheet("Table S2",
      ["Reference", "Trial", "NCT", "Indication", "Age band",
       "Infused (n)", "Evaluable (n)", "Endpoint", "Events (n)",
       "Proportion (%)", "95% CI", "Data cutoff", "Role in synthesis"],
      s2_rows, [22, 26, 16, 11, 10, 11, 12, 13, 11, 16, 14, 18, 30],
      title="Table S2. Extracted data by source",
      notes=["Infused and Evaluable are reported adjacently so that the "
             "denominator-maturity gradient discussed in manuscript Section "
             "4.3 is inspectable: 53%, 73%, 67% and 98% respectively for the "
             "four quantitative rows.",
             "Row 5 is the same cohort as row 1 under the regulatory "
             "denominator, which retains a child who died before Month 16 as "
             "a non-achiever. It is a sensitivity input, not an additional "
             "study.",
             "The 16 January 2026 cutoff is the only date in the package not "
             "independently verified. Confirm against the primary "
             "publication's Methods."],
      wrap_cols=(13,))

# ------------------------------------------------------------ TABLE S3
s3_rows = [
    ["Primary (published denominator)", "TDT", "5-11 y", "1", "100.0",
     "63.1-100.0", "n/e", "n/e", "Exact Clopper-Pearson", "Yes (8/8)"],
    ["Primary (published denominator)", "TDT", "All ages", "2", "92.0",
     "79.3-97.1", "0.000", "0", "DerSimonian-Laird, logit", "Yes (8/8 row)"],
    (["Sensitivity (regulatory denominator)", "TDT", "5-11 y", "1", "88.9",
      "51.8-99.7", "n/e", "n/e", "Exact Clopper-Pearson", "No (8/9)"], "NEW"),
    (["Sensitivity (regulatory denominator)", "TDT", "All ages", "2", "90.9",
      "78.0-96.5", "0.000", "0", "DerSimonian-Laird, logit", "No (8/9 row)"], "NEW"),
    ["Primary (published denominator)", "SCD", "5-11 y", "1", "100.0",
     "63.1-100.0", "n/e", "n/e", "Exact Clopper-Pearson", "Yes (8/8)"],
    ["Primary (published denominator)", "SCD", "All ages", "2", "97.6",
     "84.5-99.7", "0.000", "0", "DerSimonian-Laird, logit", "Yes (8/8 row)"],
    (["[COMPLETE] Sensitivity (data maturity), SCD all ages", "SCD",
      "All ages", "2", "", "", "", "", "DerSimonian-Laird, logit", ""], "TODO"),
]
ws3 = sheet("Table S3",
            ["Analysis", "Indication", "Stratum", "k", "Estimate (%)",
             "95% CI", "tau-squared", "I-squared (%)", "Model",
             "Continuity correction applied"],
            s3_rows, [34, 12, 11, 6, 13, 14, 13, 13, 24, 26],
            title="Table S3. Pooled and sensitivity estimates "
                  "(manuscript Table 3)",
            notes=[
                "k = number of contributing data rows. n/e = not estimable "
                "at k=1.",
                "The published paediatric TDT proportion of 8/8 lies on the "
                "boundary of the parameter space and required a 0.5 "
                "continuity correction for logit transformation. The "
                "regulatory proportion of 8/9 is interior and did not. The "
                "relative weight of the paediatric stratum therefore rises "
                "from 14.7% to 24.5% between the two analyses, and the "
                "weights are NOT comparable on a weight-for-weight basis.",
                "SCD estimates are unchanged under the regulatory "
                "denominator because the label and the publication report "
                "the same denominator for that indication.",
                "The data-maturity sensitivity analysis (substituting 29/30 "
                "for 45/45) is described narratively in the manuscript but "
                "its numerical output has not been computed. Run it through "
                "the deposited script and complete the pink row, or delete "
                "the row.",
                "Analyses in Python (numpy, scipy), cross-validated in R "
                "4.3.3 with metafor 4.4.0 using rma(measure='PLO', "
                "method='DL'). All four primary strata matched exactly.",
            ],
            wrap_cols=(1,))

# ------------------------------------------------------------ TABLE S4
s4_rows = [
    ["Frangoul et al. 2026a — TDT arm", "Y", "Y", "Y", "Y", "P", "Y",
     "Y", "P", "Y", "Y", "8/10",
     "Q5 and Q8 partial: 7 of 15 not yet evaluable at cutoff, disclosed "
     "rather than concealed"],
    ["Frangoul et al. 2026a — SCD arm", "Y", "Y", "Y", "Y", "P", "Y",
     "Y", "P", "Y", "Y", "8/10",
     "Q5 and Q8 partial: 3 of 11 not yet evaluable at cutoff"],
    ["Locatelli et al. 2024 — TDT", "Y", "Y", "Y", "Y", "P", "Y", "Y",
     "Y", "Y", "Y", "9/10",
     "Q5 partial: 35 of 52 evaluable at cutoff, protocol-defined window"],
    ["Grupp et al. 2025 — SCD", "Y", "Y", "Y", "U", "Y", "P", "P", "Y",
     "U", "Y", "7/10",
     "Q4 and Q9 unclear, Q6 and Q7 partial: conference-poster format is "
     "less granular. Q5 and Q8 fully met, final complete analysis"],
]
sheet("Table S4",
      ["Source and arm", "Q1", "Q2", "Q3", "Q4", "Q5", "Q6", "Q7", "Q8",
       "Q9", "Q10", "Total", "Basis for deductions"],
      s4_rows, [32, 5, 5, 5, 5, 5, 5, 5, 5, 5, 6, 8, 62],
      title="Table S4. JBI Critical Appraisal Checklist for Case Series, "
            "item-level scoring",
      notes=["Y = yes, criterion met. P = partial. U = unclear. "
             "N = no, criterion not met.",
             "No study was downgraded for its inherent single-arm design; "
             "that feature is addressed in the GRADE assessment, not here.",
             "Deductions reflect disclosed data-maturity features and "
             "reporting-format granularity rather than conduct flaws, which "
             "is why the risk-of-bias domain was not further downgraded in "
             "GRADE (manuscript Section 4.11)."],
      wrap_cols=(1, 13))

# ------------------------------------------------------ DATA DICTIONARY
dd_rows = [
    ["TI12", "Transfusion independence for at least 12 consecutive months",
     "Primary efficacy endpoint, TDT"],
    ["VF12", "Freedom from severe vaso-occlusive crises for at least 12 "
     "consecutive months", "Primary efficacy endpoint, SCD"],
    ["Infused (n)", "Participants who received the exa-cel infusion",
     "Denominator for safety outcomes"],
    ["Evaluable (n)", "Participants who had reached the protocol-defined "
     "evaluation window at data cutoff",
     "Denominator for efficacy outcomes; see Section 4.3"],
    ["Published denominator", "Evaluable participants as reported in the "
     "peer-reviewed primary source; excludes a participant who died before "
     "the evaluation window", "8 of 8 for paediatric TDT"],
    ["Regulatory denominator", "Efficacy-evaluable participants as stated "
     "in the approved prescribing information; retains a participant who "
     "died before the evaluation window as a non-achiever",
     "8 of 9 for paediatric TDT"],
    ["k", "Number of data rows contributing to an estimate",
     "Protocol minimum for formal pooling is 3; not met by any stratum"],
    ["n/e", "Not estimable", "Heterogeneity statistics at k=1"],
    ["Continuity correction", "0.5 added to both cells of a proportion "
     "lying at 0% or 100% to permit logit transformation",
     "Applied to the 8/8 rows only"],
    ["VOD", "Veno-occlusive disease, also termed sinusoidal obstruction "
     "syndrome", "Principal conditioning-related toxicity"],
    ["AUC", "Cumulative busulfan exposure, area under the concentration-"
     "time curve, in mg.h/L", "Target range 74-90; the fatal case reached 93.5"],
    ["E1-E4", "Pre-specified title-and-abstract exclusion codes",
     "Defined in the registered protocol"],
    ["Overlap chain", "A sequence of reports describing the same maturing "
     "patient cohort", "Paediatric cohort: four reports"],
    ["GRADE", "Grading of Recommendations, Assessment, Development and "
     "Evaluation, adapted for case series",
     "Very low certainty for all outcomes"],
]
sheet("Data Dictionary", ["Term", "Definition", "Note in this review"],
      dd_rows, [26, 62, 48],
      title="Data dictionary",
      wrap_cols=(2, 3))

OUT = "/mnt/user-data/outputs/Supplementary Data Package v4.xlsx"
wb.save(OUT)
print("written:", OUT)
print("sheets:", wb.sheetnames)
