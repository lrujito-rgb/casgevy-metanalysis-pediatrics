#!/usr/bin/env python3
"""
Figure 1 — PRISMA 2020 flow diagram
Casgevy SR-MA (Angle A: ages 5-11 years)

v4 (27 Sep 2026): counts revised after the search window was set to
4 August 2026, which brings the FDA supplemental approval of 1 July 2026
and its revised prescribing information into scope as an identified,
full-text-excluded regulatory document.

Changes from v3:
    identified          1831 -> 1832
    screened            1073 -> 1074
    full text assessed    66 -> 67
    full text excluded    55 -> 56
    regulatory documents   2 -> 3
    included (unchanged)      11

Canonical PRISMA 2020 layout. Greyscale, no colour. 600 dpi.
"""

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrow
from matplotlib import font_manager

# ----------------------------------------------------------------- style
FONT = "Liberation Sans"
if FONT not in {f.name for f in font_manager.fontManager.ttflist}:
    FONT = "DejaVu Sans"

plt.rcParams.update({
    "font.family": FONT,
    "text.color": "black",
})

EDGE = "black"
LW = 1.4
FILL = "white"
BAND = "#D9D9D9"          # phase-label bars
BOX_FS = 10.0             # box body text
PHASE_FS = 12.0           # rotated phase labels

# ----------------------------------------------------------------- counts
N_IDENTIFIED   = 1832
N_DUPES        = 758      # 1832 - 1074
N_SCREENED     = 1074
N_EXCL_TA      = 1007
N_SOUGHT       = 67
N_NOT_RETR     = 0
N_ASSESSED     = 67
N_EXCL_FT      = 56
N_INCLUDED     = 11

assert N_IDENTIFIED - N_DUPES == N_SCREENED
assert N_SCREENED - N_EXCL_TA == N_SOUGHT
assert N_SOUGHT - N_NOT_RETR == N_ASSESSED
assert N_ASSESSED - N_EXCL_FT == N_INCLUDED
assert 120 + 22 + 851 + 14 == N_EXCL_TA
assert 38 + 11 + 3 + 3 + 1 == N_EXCL_FT

# ----------------------------------------------------------------- canvas
FIG_W_IN, FIG_H_IN = 9.2, 11.8
DPI = 600

fig, ax = plt.subplots(figsize=(FIG_W_IN, FIG_H_IN))
ax.set_xlim(0, 100)
ax.set_ylim(5, 100)
ax.axis("off")
ax.set_position([0, 0, 1, 1])

_boxes = []


def box(x, y, w, h, lines, fs=BOX_FS, align="left", bold_first=False):
    """Draw a bordered white box with padded, vertically centred text."""
    r = Rectangle((x, y), w, h, facecolor=FILL, edgecolor=EDGE,
                  linewidth=LW, zorder=2)
    ax.add_patch(r)
    _boxes.append(r)

    pad_x = 1.5
    txt = "\n".join(lines)
    if align == "left":
        ax.text(x + pad_x, y + h / 2, txt, ha="left", va="center",
                fontsize=fs, linespacing=1.45, zorder=3,
                fontweight="bold" if bold_first else "normal")
    else:
        ax.text(x + w / 2, y + h / 2, txt, ha="center", va="center",
                fontsize=fs, linespacing=1.45, zorder=3,
                fontweight="bold" if bold_first else "normal")
    return r


def phase(y, h, label):
    """Left-hand shaded phase band with rotated label."""
    r = Rectangle((1.0, y), 5.2, h, facecolor=BAND, edgecolor=EDGE,
                  linewidth=LW, zorder=2)
    ax.add_patch(r)
    _boxes.append(r)
    ax.text(1.0 + 5.2 / 2, y + h / 2, label, ha="center", va="center",
            rotation=90, fontsize=PHASE_FS, fontweight="bold", zorder=3)


def arrow_down(x, y_from, y_to):
    ax.annotate("", xy=(x, y_to), xytext=(x, y_from),
                arrowprops=dict(arrowstyle="-|>", color=EDGE,
                                linewidth=LW, mutation_scale=16), zorder=1)


def arrow_right(y, x_from, x_to):
    ax.annotate("", xy=(x_to, y), xytext=(x_from, y),
                arrowprops=dict(arrowstyle="-|>", color=EDGE,
                                linewidth=LW, mutation_scale=16), zorder=1)


# ----------------------------------------------------------------- geometry
LX, LW_ = 9.0, 46.0        # left (main) column
RX, RW_ = 61.0, 37.0       # right (exclusion) column
LCX = LX + LW_ / 2         # centre of main column

# ---- IDENTIFICATION -------------------------------------------------
phase(84.0, 14.5, "Identification")

box(LX, 89.0, LW_, 9.0, [
    f"Records identified (n = {N_IDENTIFIED:,}):",
    "   Five electronic databases (PubMed/MEDLINE,",
    "   Embase, Cochrane CENTRAL, Scopus, Web of Science)",
    "   Grey literature: trial registers, regulatory",
    "   documents, conference proceedings",
], fs=9.4)

box(RX, 89.0, RW_, 9.0, [
    "Records removed before screening:",
    f"   Duplicate records removed (n = {N_DUPES:,})",
], fs=9.4)

arrow_right(93.5, LX + LW_, RX)

# ---- SCREENING ------------------------------------------------------
phase(29.0, 53.5, "Screening")

arrow_down(LCX, 89.0, 79.5)

box(LX, 72.5, LW_, 7.0, [f"Records screened (n = {N_SCREENED:,})"],
    align="center")

box(RX, 63.0, RW_, 16.5, [
    f"Records excluded at title/abstract (n = {N_EXCL_TA:,}):",
    "   Concordant reviewer judgement (n = 120)",
    "   Excluded after third-reviewer adjudication (n = 22)",
    "   Conservative screening exclusion with valid",
    "      E1\u2013E4 code (n = 851)",
    "   Ineligible investigational product (n = 14)",
], fs=9.4)

arrow_right(76.0, LX + LW_, RX)

arrow_down(LCX, 72.5, 62.5)

box(LX, 55.5, LW_, 7.0, [f"Reports sought for retrieval (n = {N_SOUGHT})"],
    align="center")

box(RX, 55.5, RW_, 7.0, [f"Reports not retrieved (n = {N_NOT_RETR})"],
    fs=9.4, align="center")

arrow_right(59.0, LX + LW_, RX)

arrow_down(LCX, 55.5, 45.5)

box(LX, 38.5, LW_, 7.0, [f"Reports assessed for eligibility (n = {N_ASSESSED})"],
    align="center")

box(RX, 29.0, RW_, 16.5, [
    f"Reports excluded at full text (n = {N_EXCL_FT}):",
    "   Superseded or duplicate report of an already-",
    "      represented patient cohort (n = 38)",
    "   Trial-register entry, no extractable outcome (n = 11)",
    "   Regulatory document, ineligible as a study (n = 3)",
    "   Non-poolable or out of scope (n = 3)",
    "   Ineligible investigational product (n = 1)",
], fs=9.4)

arrow_right(42.0, LX + LW_, RX)

# ---- INCLUDED -------------------------------------------------------
phase(7.5, 20.5, "Included")

arrow_down(LCX, 38.5, 28.0)

box(LX, 20.0, LW_, 8.0, [
    f"Studies included in qualitative synthesis",
    f"(n = {N_INCLUDED})",
], align="center")

arrow_down(LCX, 20.0, 13.5)

box(LX, 8.5, LW_, 5.0, [
    "Contributing to quantitative synthesis:",
    "2 primary reports, 4 data rows",
], align="center", fs=9.4)

# ----------------------------------------------------------------- checks
expected_boxes = 10 + 3          # 10 content boxes + 3 phase bands
assert len(_boxes) == expected_boxes, f"box count {len(_boxes)}"
missing = [b for b in _boxes if b.get_edgecolor()[3] == 0 or b.get_linewidth() == 0]
assert not missing, "a box rendered without a border"

# ----------------------------------------------------------------- output
OUT = "/mnt/user-data/outputs/Figure 1 PRISMA flow HD v4.png"
fig.savefig(OUT, dpi=DPI, format="png", facecolor="white",
            bbox_inches="tight", pad_inches=0.18)
fig.savefig(OUT.replace(".png", ".pdf"), format="pdf", facecolor="white",
            bbox_inches="tight", pad_inches=0.18)
plt.close(fig)

print(f"boxes drawn : {len(_boxes)}")
print(f"arithmetic  : all reconciliation checks passed")
print(f"written     : {OUT}")
