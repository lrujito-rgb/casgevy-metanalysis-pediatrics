#!/usr/bin/env python3
"""
Figure 2 — forest plot of primary efficacy estimates
Casgevy SR-MA (Angle A: ages 5-11 years)

v2 (27 Sep 2026). Changes from v1:
  1. Internal working identifiers (uid154, uid6, uid416) replaced with
     author-date citations that resolve against the reference list.
  2. Greyscale, matching Figure 1. The previous blue/red coding carried no
     information beyond the indication, which the row labels already state.
  3. x-axis capped at 100. A proportion cannot exceed 100%, so the previous
     axis running to 120 implied an impossible region.
  4. Title no longer calls every row "pooled": two of the six rows are
     single-study exact estimates, not pooled.
  5. Regulatory-denominator sensitivity estimates added as open markers
     (manuscript Table 3, Section 4.3).
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.lines import Line2D

FONT = "Liberation Sans"
if FONT not in {f.name for f in font_manager.fontManager.ttflist}:
    FONT = "DejaVu Sans"
plt.rcParams.update({"font.family": FONT, "text.color": "black"})

INK = "black"
GREY = "#666666"

# ---------------------------------------------------------------- data
# (y, label_line1, label_line2, est, lo, hi, primary?)
ROWS = [
    (6.10, "TDT \u2014 ages 5\u201311 y",
     "Frangoul et al., 2026a; k=1, exact CI", 100.0, 63.1, 100.0, True),
    (5.30, "TDT \u2014 ages 5\u201311 y, sensitivity",
     "Regulatory denominator (8/9); k=1, exact CI", 88.9, 51.8, 99.7, False),
    (4.20, "TDT \u2014 all ages",
     "Locatelli et al., 2024 + Frangoul et al., 2026a; k=2, DL logit",
     92.0, 79.3, 97.1, True),
    (3.40, "TDT \u2014 all ages, sensitivity",
     "Regulatory denominator (8/9); k=2, DL logit", 90.9, 78.0, 96.5, False),
    (2.10, "SCD \u2014 ages 5\u201311 y",
     "Frangoul et al., 2026a; k=1, exact CI", 100.0, 63.1, 100.0, True),
    (1.20, "SCD \u2014 all ages",
     "Grupp et al., 2025 + Frangoul et al., 2026a; k=2, DL logit",
     97.6, 84.5, 99.7, True),
]

XMIN, XMAX = 45.0, 100.0
for _, _, _, e, lo, hi, _ in ROWS:
    assert XMIN <= lo <= e <= hi <= XMAX, "estimate outside plotted range"

# ---------------------------------------------------------------- canvas
fig = plt.figure(figsize=(11.6, 8.4))
DPI = 600

# axes occupies the middle band; labels left, values right
ax = fig.add_axes([0.335, 0.435, 0.395, 0.495])
ax.set_xlim(XMIN, XMAX)
ax.set_ylim(0.45, 6.95)
ax.set_yticks([])
ax.spines[["top", "right", "left"]].set_visible(False)
ax.spines["bottom"].set_linewidth(1.1)
ax.spines["bottom"].set_color(INK)
ax.set_xticks([50, 60, 70, 80, 90, 100])
ax.tick_params(axis="x", labelsize=10.5, colors=INK, width=1.1, length=5)
ax.set_xlabel("Proportion achieving the primary endpoint\n"
              "(TI12 for TDT; VF12 for SCD), % with 95% CI",
              fontsize=10.5, labelpad=9)

ax.axvline(100, color=GREY, linestyle=(0, (2, 3)), linewidth=1.0, zorder=1)

# indication separator
ax.axhline(2.75, color="#BBBBBB", linewidth=0.9, zorder=0)

for y, l1, l2, est, lo, hi, primary in ROWS:
    ax.plot([lo, hi], [y, y], color=INK,
            linewidth=1.9 if primary else 1.3,
            solid_capstyle="butt", zorder=3)
    for b in (lo, hi):                      # CI end caps
        ax.plot([b, b], [y - 0.11, y + 0.11], color=INK,
                linewidth=1.9 if primary else 1.3, zorder=3)
    ax.plot([est], [y], marker="s", markersize=10 if primary else 9,
            markerfacecolor=INK if primary else "white",
            markeredgecolor=INK, markeredgewidth=1.6, zorder=4)

    # row label, right-aligned in the left margin
    fig.text(0.322, fig.transFigure.inverted().transform(
        ax.transData.transform((XMIN, y)))[1] + 0.0125,
        l1, ha="right", va="center", fontsize=10.5,
        fontweight="bold" if primary else "normal")
    fig.text(0.322, fig.transFigure.inverted().transform(
        ax.transData.transform((XMIN, y)))[1] - 0.0135,
        l2, ha="right", va="center", fontsize=8.6, color="#333333")

    # numeric estimate, left-aligned in the right margin
    fig.text(0.745, fig.transFigure.inverted().transform(
        ax.transData.transform((XMIN, y)))[1],
        f"{est:.1f}% ({lo:.1f}\u2013{hi:.1f})", ha="left", va="center",
        fontsize=10.5, fontweight="bold" if primary else "normal")

fig.text(0.5, 0.985,
         "Figure 2. Primary efficacy estimates by indication and age stratum",
         ha="center", va="top", fontsize=13.5, fontweight="bold")

legend = [
    Line2D([0], [0], marker="s", color="white", markerfacecolor=INK,
           markeredgecolor=INK, markersize=9,
           label="Primary analysis, published denominator"),
    Line2D([0], [0], marker="s", color="white", markerfacecolor="white",
           markeredgecolor=INK, markeredgewidth=1.6, markersize=9,
           label="Sensitivity analysis, regulatory denominator"),
]
fig.legend(handles=legend, loc="upper left", bbox_to_anchor=(0.335, 0.355),
           bbox_transform=fig.transFigure, frameon=False, fontsize=9.6,
           handletextpad=0.7, ncol=2, columnspacing=2.6, borderaxespad=0)

FOOT = (
    "Rows with k=1 show the exact (Clopper\u2013Pearson) 95% CI for a single "
    "non-overlapping study and are not meta-analytic pooled estimates. Rows "
    "with k=2 show DerSimonian\u2013Laird random-effects estimates on\n"
    "logit-transformed proportions with 0.5 continuity correction. Both fall "
    "below this review's pre-registered minimum of three studies for formal "
    "pooling (PROSPERO CRD420261420579); heterogeneity statistics and\n"
    "prediction intervals are not shown, neither being estimable at this "
    "study count. Denominators are evaluable rather than infused "
    "participants. The sensitivity rows substitute the efficacy-evaluable\n"
    "denominator stated in the approved prescribing information, which "
    "retains a child who died before the Month 16 evaluation window as a "
    "non-achiever (Table 3; Section 4.3); the 8/8 proportions required a\n"
    "continuity correction and the 8/9 proportions did not, so study weights "
    "are not comparable between the two analyses. SCD estimates are unchanged "
    "under the regulatory denominator. TI12: transfusion\n"
    "independence \u226512 months. VF12: freedom from severe vaso-occlusive "
    "crises \u226512 months. Analyses in Python, cross-validated in R "
    "(metafor::rma, measure PLO, method DL)."
)
fig.text(0.035, 0.275, FOOT, ha="left", va="top", fontsize=8.2,
         linespacing=1.55, color="#222222")

OUT = "/mnt/user-data/outputs/Figure 2 forest pooled proportions HD v2.png"
fig.savefig(OUT, dpi=DPI, facecolor="white", bbox_inches="tight",
            pad_inches=0.16)
fig.savefig(OUT.replace(".png", ".pdf"), facecolor="white",
            bbox_inches="tight", pad_inches=0.16)
plt.close(fig)

print("rows plotted :", len(ROWS))
print("range check  : all estimates and CIs within", XMIN, "-", XMAX)
print("written      :", OUT)
